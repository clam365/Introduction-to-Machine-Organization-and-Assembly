/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_301(unsigned x)
{
    return x + 3351742792U;
}

unsigned addval_269(unsigned x)
{
    return x + 2428995912U;
}

void setval_250(unsigned *p)
{
    *p = 969111561U;
}

unsigned getval_391()
{
    return 3284633928U;
}

unsigned addval_223(unsigned x)
{
    return x + 3285730946U;
}

unsigned addval_270(unsigned x)
{
    return x + 2428995916U;
}

unsigned getval_178()
{
    return 3277339336U;
}

void setval_370(unsigned *p)
{
    *p = 3281031256U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_420()
{
    return 2425408137U;
}

unsigned getval_326()
{
    return 2430634440U;
}

unsigned getval_164()
{
    return 2425408201U;
}

void setval_328(unsigned *p)
{
    *p = 3677929864U;
}

unsigned addval_480(unsigned x)
{
    return x + 3234125449U;
}

unsigned getval_147()
{
    return 3523791529U;
}

unsigned addval_373(unsigned x)
{
    return x + 3674784137U;
}

unsigned getval_385()
{
    return 3767093437U;
}

unsigned getval_387()
{
    return 3525888649U;
}

unsigned addval_137(unsigned x)
{
    return x + 3677929857U;
}

unsigned getval_129()
{
    return 3281049225U;
}

void setval_358(unsigned *p)
{
    *p = 2864958093U;
}

unsigned addval_368(unsigned x)
{
    return x + 3229925769U;
}

unsigned getval_455()
{
    return 3269495112U;
}

void setval_462(unsigned *p)
{
    *p = 3230979721U;
}

void setval_205(unsigned *p)
{
    *p = 3286272072U;
}

void setval_288(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_496(unsigned x)
{
    return x + 2430634313U;
}

unsigned getval_393()
{
    return 3674789545U;
}

unsigned getval_479()
{
    return 3281049225U;
}

void setval_187(unsigned *p)
{
    *p = 3531917961U;
}

unsigned getval_421()
{
    return 3523270281U;
}

unsigned getval_335()
{
    return 2464188744U;
}

void setval_478(unsigned *p)
{
    *p = 3682124169U;
}

void setval_103(unsigned *p)
{
    *p = 3267463534U;
}

unsigned addval_189(unsigned x)
{
    return x + 2430634056U;
}

unsigned addval_414(unsigned x)
{
    return x + 3281049097U;
}

unsigned addval_417(unsigned x)
{
    return x + 2425667977U;
}

unsigned addval_451(unsigned x)
{
    return x + 3222850185U;
}

void setval_197(unsigned *p)
{
    *p = 3227566473U;
}

void setval_255(unsigned *p)
{
    *p = 3221804713U;
}

void setval_468(unsigned *p)
{
    *p = 3676359177U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
